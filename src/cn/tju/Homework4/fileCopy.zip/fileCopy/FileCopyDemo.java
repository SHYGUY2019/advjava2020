package fileCopy;

import java.io.IOException;

public class FileCopyDemo {

	public static void main(String[] args) throws IOException {
		FileCopy.copy("./src/output.txt", "./");
	}

}
