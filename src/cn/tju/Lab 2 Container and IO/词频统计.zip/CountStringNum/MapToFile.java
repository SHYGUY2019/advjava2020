package CountStringNum;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

public class MapToFile {
//输入的map
	Map<String,Integer> map;
	
	public MapToFile(Map<String,Integer> map) {
		this.map = map; 
	}
	
	public void toFile(String path) throws IOException {
		File file = new File(path);
		
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
			file.createNewFile();
		} else if(!file.exists()){
			file.createNewFile();
		}else{
			System.out.println("文件已存在! ");
			return;
		}
		
		try {
			OutputStream out = new FileOutputStream(file);
			for(String k:this.map.keySet()) {
				String str = k+" "+this.map.get(k)+"\n";
				byte data[] = str.getBytes();
				out.write(data);
	    	}
			out.close();
		} catch (FileNotFoundException e) {}
	}
}
