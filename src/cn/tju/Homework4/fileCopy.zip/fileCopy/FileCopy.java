package fileCopy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileCopy {
	private static String filename;
    private final static Integer SIZE = 1024;
    
    private static String readIn(String path) throws IOException {
    	File file = new File(path);
    	filename = file.getName();
    	if (!file.exists()) {
    		System.out.println("文件不存在");
    		return null;
    	} else {
    		InputStream in = new FileInputStream(file);
    		byte data[] = new byte[SIZE*SIZE];
    		int length = in.read(data);
    		in.close();
    		String str = new String(data,0,length);
    		return str;
    	}
    }
    
    private static void writeOut(String str, String path) throws IOException {
    	File fileDirectory = new File(path);
    	if(!fileDirectory.isDirectory()) {
    		System.out.println("输入的不是一个目录");
    	} else if (!fileDirectory.exists()) {
    		fileDirectory.mkdirs();
    	} else {
    		File file = new File(path+File.separator+filename);
    		OutputStream out = new FileOutputStream(file);
    		byte data[] = new byte[SIZE*SIZE];
    		data = str.getBytes();
    		out.write(data);
    		out.close();
    		System.out.println("复制成功");
    	}
    }
    
    public static void copy(String source, String destination) throws IOException {
    	writeOut(readIn(source), destination);
    }
}
