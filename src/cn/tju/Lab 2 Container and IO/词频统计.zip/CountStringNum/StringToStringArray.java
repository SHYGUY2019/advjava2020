package CountStringNum;

public class StringToStringArray {
    private String string = "";
    
    public StringToStringArray(String str) {
    	this.string = str;
    }
    
    public String[] toStringArray() {
    	return this.string.split("\\s+");
    }
}
