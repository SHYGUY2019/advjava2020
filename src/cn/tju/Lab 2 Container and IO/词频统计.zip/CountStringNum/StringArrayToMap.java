package CountStringNum;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StringArrayToMap {
	private static<K, V extends Comparable<? super V>> Map<K, V> sortDescend(Map<K, V> map) {
        List<Map.Entry<K, V>> list = new ArrayList<>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            @Override
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                int compare = (o1.getValue()).compareTo(o2.getValue());
                return -compare;
            }
        });
 
        Map<K, V> returnMap = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list) {
            returnMap.put(entry.getKey(), entry.getValue());
        }
        return returnMap;
    }

    public static Map<String,Integer> count(String[] str) {
    	Map<String,Integer> map = new HashMap<>();

    	for(int i = 0;i < str.length;i++) {
    		if(!map.containsKey(str[i])) {
    			map.put(str[i],1);
    		} else {
    			int count = map.get(str[i]);
    			map.put(str[i], ++count);
    		}	
    	}
    	
    	return StringArrayToMap.sortDescend(map);
    	
//    	for(String k:sortMap.keySet()) {
//    		System.out.println(k+" "+sortMap.get(k));
//    	}
    }
}
