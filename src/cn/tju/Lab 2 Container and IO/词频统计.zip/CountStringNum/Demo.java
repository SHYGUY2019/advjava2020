package CountStringNum;

import java.io.IOException;

public class Demo {
    public static void main(String[] args) throws IOException {
    	FileToString f = new FileToString("./src/了不起的盖茨比英文.txt");
    	String s = f.toString();

    	String[] str = new StringToStringArray(s).toStringArray();
    	
    	MapToFile mtf = new MapToFile(StringArrayToMap.count(str));
    	mtf.toFile("./src/output.txt");
    }
}
