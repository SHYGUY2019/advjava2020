package reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public class Sql implements SqlUtil {

	@Override
	public String query(User user) {
		StringBuilder sb = new StringBuilder();
		
//		1. 获取Class
		Class<? extends User> clazz = user.getClass();
//		判断是否包含Table类型的注解
		if (!clazz.isAnnotationPresent(Table.class)) {
			return null;
		}
		
//		2. 获取到Table的名字
		Table t = (Table)clazz.getAnnotation(Table.class);
		String tableName = t.value();

		sb.append("SELSCT * FROM ").append(tableName);
		
//		获取类属性的所有字段
		Field[] fArray = clazz.getDeclaredFields();
//		3. 遍历所有字段
		for (Field field : fArray) {
//			4. 处理每个字段对应的sql
//			判断是否包含Column类型的注解
			if (!field.isAnnotationPresent(Column.class)) {
				continue;
			}
			
//			4.1 拿到Column注解上面的值
			Column column = field.getAnnotation(Column.class);
			String columnName = column.value();
//			System.out.println(columnName);
//			4.2 拿到字段的名字
			String fieldName = field.getName();
//			System.out.println(fieldName);
//			获取相应字段的get方法
			String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase()+ fieldName.substring(1);
//			字段的值，由于值的类型很多，所以设为Object
			Object fieldValue = null;
			
			try {
				Method getMethod = clazz.getMethod(getMethodName);
				fieldValue = getMethod.invoke(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
//			4.3 拼接sql
			if (fieldValue == null||fieldValue instanceof Integer&&(Integer)fieldValue == 0) {
				continue;
			}
			
			sb.append(" WHERE ").append(fieldName);
			if(fieldValue instanceof String){
				if(((String)fieldValue).contains(",")){
					String[] values = ((String)fieldValue).split(",");
					sb.append(" IN(");
					for (String v : values) {
						sb.append("'").append(v).append("'").append(",");
					}
					sb.deleteCharAt(sb.length()-1);
					sb.append(")");
				}
				else{
					sb.append(" LIKE ").append("'").append(fieldValue).append("'");
				}
			}
			else if(fieldValue instanceof Integer){
				sb.append(" = ").append(fieldValue);
			}

		}
		return sb.toString();
	}

	@Override
	public String insert(User user) {
		StringBuilder sb = new StringBuilder();
		
//		1. 获取class
		Class clazz = user.getClass();
//		判断是否包含Table类型的注解
		if (!clazz.isAnnotationPresent(Table.class)) {
			return null;
		}
		
//		2. 获取Table的名字
		Table table = (Table)clazz.getAnnotation(Table.class);
		String tableName = table.value();
		
		sb.append("INSERT INTO ").append(tableName);
		
//		3. 获取类属性的所有字段
		Field[] fArray = clazz.getDeclaredFields();
//		设置一个属性列表
		StringBuilder attribute = new StringBuilder(" (");
//		设置一个属性值列表
		StringBuilder attributeValue = new StringBuilder(" VALUES (");
//		遍历字段
		for (Field field:fArray) {
//			4. 处理每个字段
//			判断是否包含Column类型的注解
			if (!field.isAnnotationPresent(Column.class)) {
				System.out.println("无效插入信息");
				continue;
			}
//			4.1 拿到Column注解上面的值
			Column column = field.getAnnotation(Column.class);
			String columnName = column.value();
//			4.2 拿到字段的名字
			String fieldName = field.getName();
//			获取相应字段的get方法
			String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase()+ fieldName.substring(1);
//			字段的值，由于值的类型很多，所以设为Object
			Object fieldValue = null;
			
			try {
				Method getMethod = clazz.getMethod(getMethodName);
				fieldValue = getMethod.invoke(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
//			4.3 构造插入列表
			if (fieldValue == null||fieldValue instanceof Integer&&(Integer)fieldValue == 0) {
				continue;
			}
		
			attribute.append("`").append(fieldName).append("`, ");
			
			attributeValue.append("`").append(fieldValue).append("`, ");
			
		}
		attribute.deleteCharAt(attribute.length()-1).deleteCharAt(attribute.length()-1).append(")");
		attributeValue.deleteCharAt(attributeValue.length()-1).deleteCharAt(attributeValue.length()-1).append(")");
//		4.4 拼接
		sb.append(attribute).append(attributeValue);
		return sb.toString();
	}

	@Override
	public String insert(List<User> users) {
		boolean isTable = true;
		for (User user:users) {
			Class clazz = user.getClass();
			isTable = isTable && clazz.isAnnotationPresent(Table.class);
		}
		
		if(!isTable) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder("INSERT INTO ");
		
//		获取table
		Table table = users.get(0).getClass().getAnnotation(Table.class);
		String tableName = table.value();
		sb.append(tableName);
		
//		设置一个属性列表
		StringBuilder attribute = new StringBuilder(" (");
//		设置一个属性值列表数组，大小为users的长度
		StringBuilder[] attributeValues = new StringBuilder[users.size()];
		
//		3. 循环获取类属性的所有字段
		for (int i = 0; i < attributeValues.length; i++) {
			User user = users.get(i);
			Class clazz = user.getClass();
			Field[] fArray = clazz.getDeclaredFields();
			attributeValues[i] = new StringBuilder("(");
//			遍历字段
			for (Field field:fArray) {
//				4. 处理每个字段
//				判断是否包含Column类型的注解
				if (!field.isAnnotationPresent(Column.class)) {
					System.out.println("无效插入信息");
					continue;
				}
//				4.1 拿到Column注解上面的值
				Column column = field.getAnnotation(Column.class);
				String columnName = column.value();
//				4.2 拿到字段的名字
				String fieldName = field.getName();
//				获取相应字段的get方法
				String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase()+ fieldName.substring(1);
//				字段的值，由于值的类型很多，所以设为Object
				Object fieldValue = null;
				
				try {
					Method getMethod = clazz.getMethod(getMethodName);
					fieldValue = getMethod.invoke(user);
				} catch (Exception e) {
					e.printStackTrace();
				}
//				4.3 构造插入列表
				if (fieldValue == null||fieldValue instanceof Integer&&(Integer)fieldValue == 0) {
					continue;
				}
			
				if(i == 0) {
					attribute.append("`").append(fieldName).append("`, ");
				}
				
				
				attributeValues[i].append("`").append(fieldValue).append("`, ");
				
			}
		}
//		4.4 拼接
		attribute.deleteCharAt(attribute.length()-1).deleteCharAt(attribute.length()-1).append(") VALUES ");
		sb.append(attribute);
		for(StringBuilder attributeValue:attributeValues) {
			attributeValue.deleteCharAt(attributeValue.length()-1).deleteCharAt(attributeValue.length()-1).append(")");
			sb.append(attributeValue).append(", ");
		}

		sb.deleteCharAt(sb.length()-1).deleteCharAt(sb.length()-1);
		return sb.toString();
	}

	@Override
	public String delete(User user) {
		StringBuilder sb = new StringBuilder();
		
//		1. 获取Class
		Class<? extends User> clazz = user.getClass();
//		判断是否包含Table类型的注解
		if (!clazz.isAnnotationPresent(Table.class)) {
			return null;
		}
		
//		2. 获取到Table的名字
		Table t = (Table)clazz.getAnnotation(Table.class);
		String tableName = t.value();

		sb.append("DELETE FROM ").append(tableName);
		
//		获取类属性的所有字段
		Field[] fArray = clazz.getDeclaredFields();
//		3. 遍历所有字段
		for (Field field : fArray) {
//			4. 处理每个字段对应的sql
//			判断是否包含Column类型的注解
			if (!field.isAnnotationPresent(Column.class)) {
				continue;
			}
			
//			4.1 拿到Column注解上面的值
			Column column = field.getAnnotation(Column.class);
			String columnName = column.value();
//			System.out.println(columnName);
//			4.2 拿到字段的名字
			String fieldName = field.getName();
//			System.out.println(fieldName);
//			获取相应字段的get方法
			String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase()+ fieldName.substring(1);
//			字段的值，由于值的类型很多，所以设为Object
			Object fieldValue = null;
			
			try {
				Method getMethod = clazz.getMethod(getMethodName);
				fieldValue = getMethod.invoke(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
//			4.3 拼接sql
			if (fieldValue == null||fieldValue instanceof Integer&&(Integer)fieldValue == 0) {
				continue;
			}
			
			sb.append(" WHERE ").append(fieldName);
			if(fieldValue instanceof String){
				if(((String)fieldValue).contains(",")){
					String[] values = ((String)fieldValue).split(",");
					sb.append(" IN(");
					for (String v : values) {
						sb.append("'").append(v).append("'").append(",");
					}
					sb.deleteCharAt(sb.length()-1);
					sb.append(")");
				}
				else{
					sb.append(" = ").append("'").append(fieldValue).append("'");
				}
			}
			else if(fieldValue instanceof Integer){
				sb.append(" = ").append(fieldValue);
			}

		}
		return sb.toString();
	}

	@Override
	public String update(User user) {
		StringBuilder sb = new StringBuilder();
		
//		1. 获取Class
		Class<? extends User> clazz = user.getClass();
//		判断是否包含Table类型的注解
		if (!clazz.isAnnotationPresent(Table.class)) {
			return null;
		}
		
//		2. 获取到Table的名字
		Table t = (Table)clazz.getAnnotation(Table.class);
		String tableName = t.value();

		sb.append("UPDATE ").append(tableName);
		
//		获取类属性的所有字段
		Field[] fArray = clazz.getDeclaredFields();
		String id = null;
//		3. 遍历所有字段
		for (Field field : fArray) {
//			4. 处理每个字段对应的sql
//			判断是否包含Column类型的注解
			if (!field.isAnnotationPresent(Column.class)) {
				continue;
			}
			
//			4.1 拿到Column注解上面的值
			Column column = field.getAnnotation(Column.class);
			String columnName = column.value();
//			System.out.println(columnName);
//			4.2 拿到字段的名字
			String fieldName = field.getName();
//			System.out.println(fieldName);
//			获取相应字段的get方法
			String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase()+ fieldName.substring(1);
//			字段的值，由于值的类型很多，所以设为Object
			Object fieldValue = null;
			
			try {
				Method getMethod = clazz.getMethod(getMethodName);
				fieldValue = getMethod.invoke(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
//			4.3 拼接sql
			if (fieldValue == null||fieldValue instanceof Integer&&(Integer)fieldValue == 0) {
				continue;
			}
			if(!fieldName.toLowerCase().equals("id")) {
				sb.append(" SET ").append(fieldName);
				if(fieldValue instanceof String){
					sb.append(" = ").append("'").append(fieldValue).append("'");
				}
				else if(fieldValue instanceof Integer){
					sb.append(" = ").append(fieldValue);
				}
			}else {
				id = new String(fieldValue.toString());
			}
		}	
		sb.append(" WHERE id = ").append(id);
		return sb.toString();
	}

}
